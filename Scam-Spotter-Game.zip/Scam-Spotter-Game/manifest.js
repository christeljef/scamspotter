{
  "name": "Scam Spotter",
  "short_name": "ScamSpotter",
  "start_url": "./index.html",
  "display": "standalone",
  "background_color": "#0d0b1f",
  "theme_color": "#00f0ff",
  "description": "Train your scam-spotting instincts with this neon cyberpunk quiz game!",
  "icons": [
    {
      "src": "icon-scam-1.png",
      "sizes": "192x192",
      "type": "image/png"
    },
    {
      "src": "icon-scam-2.png",
      "sizes": "512x512",
      "type": "image/png"
    }
  ]
}